package com.example.basiclogintoapp;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class GetImageInfo extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private ImageView imageView;
    private TextView textView;
    private Button copyButton;
    private Bitmap selectedImage;
    private String userPrompt;
    private int selectedPromptIndex;  // Track selected prompt

    private DatabaseReference databaseRef; // Firebase Realtime Database reference

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_image_info);

        imageView = findViewById(R.id.imageView);
        textView = findViewById(R.id.textView);
        copyButton = findViewById(R.id.button);

        // Initialize Firebase Database reference
        databaseRef = FirebaseDatabase.getInstance().getReference("responses");

        // Set up copy button click listener
        copyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copyToClipboard(textView.getText().toString());
            }
        });

        showPromptSelectionDialog();
    }

    private void copyToClipboard(String text) {
        if (text.isEmpty()) {
            Toast.makeText(this, "No text to copy!", Toast.LENGTH_SHORT).show();
            return;
        }

        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("Generated Text", text);
        clipboard.setPrimaryClip(clip);

        Toast.makeText(this, "Copied to clipboard!", Toast.LENGTH_SHORT).show();
    }

    private void showPromptSelectionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select a prompt")
                .setItems(new CharSequence[]{
                        "I plan on redesigning this. What changes should I make to this place?",
                        "Upgrade Color"
                }, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        selectedPromptIndex = which;
                        if (which == 0) {
                            userPrompt = "I plan on redesigning this. What changes should I make to this place?";
                        } else {
                            userPrompt = "in one word tell me the color of this i just want the hex code";
                        }
                        startCamera();
                    }
                })
                .setCancelable(false)
                .show();
    }

    private void startCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK && data != null) {
            Bundle extras = data.getExtras();
            selectedImage = (Bitmap) extras.get("data");
            imageView.setImageBitmap(selectedImage);

            GenerativeModel gm = new GenerativeModel("gemini-2.0-flash", "AIzaSyAzIbZIrNYr9b9r3Ey7N5hTfQzg24N4ug4");
            GenerativeModelFutures model = GenerativeModelFutures.from(gm);

            Content content = new Content.Builder()
                    .addText(userPrompt)
                    .addImage(selectedImage)
                    .build();

            Executor executor = Executors.newSingleThreadExecutor();
            ListenableFuture<GenerateContentResponse> response = model.generateContent(content);

            Futures.addCallback(response, new FutureCallback<GenerateContentResponse>() {
                @Override
                public void onSuccess(GenerateContentResponse result) {
                    String resultText = result.getText().replaceAll("\\*", "");

                    runOnUiThread(() -> {
                        textView.setText(resultText);
                    });

                    // Save to Firebase
                    saveResponseToFirebase(selectedPromptIndex, resultText);
                }

                @Override
                public void onFailure(Throwable t) {
                    t.printStackTrace();
                }
            }, executor);
        }
    }

    private void saveResponseToFirebase(int promptIndex, String response) {
        String promptKey = (promptIndex == 0) ? "prompt1" : "prompt2";
        databaseRef.child(promptKey).setValue(response);
    }
}
