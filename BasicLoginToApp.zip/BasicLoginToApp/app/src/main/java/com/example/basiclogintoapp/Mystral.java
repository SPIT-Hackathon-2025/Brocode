package com.example.basiclogintoapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.vision.text.Text;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;


import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Mystral extends AppCompatActivity {

    private static final int CAMERA_PERMISSION_REQUEST_CODE = 1001;
    private static final String TAG = "MystralActivity";
    private ImageView imageView;
    private TextView textView;
    private Bitmap capturedImage;
    private final OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mystral);

        imageView = findViewById(R.id.imageView);
        textView = findViewById(R.id.textView);
        Button captureButton = findViewById(R.id.captureButton);
        Button sendButton = findViewById(R.id.sendButton);

        captureButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.CAMERA},
                        CAMERA_PERMISSION_REQUEST_CODE);
            } else {
                launchCamera();
            }
        });

        sendButton.setOnClickListener(v -> {
            if (capturedImage != null) {
                recognizeTextAndSend(capturedImage);
            } else {
                Toast.makeText(this, "Capture an image first", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void launchCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            cameraLauncher.launch(takePictureIntent);
        } else {
            Toast.makeText(this, "Camera not available", Toast.LENGTH_SHORT).show();
        }
    }

    private final ActivityResultLauncher<Intent> cameraLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            Bundle extras = result.getData().getExtras();
                            capturedImage = (Bitmap) extras.get("data");
                            imageView.setImageBitmap(capturedImage);
                        }
                    });

    private void recognizeTextAndSend(Bitmap bitmap) {
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        TextRecognizer recognizer = null;

        recognizer.process(image)
                .addOnSuccessListener(this::sendTextToServer)
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Text recognition failed", e);
                    Toast.makeText(this, "Text recognition failed", Toast.LENGTH_SHORT).show();
                });
    }

    private void sendTextToServer(com.google.mlkit.vision.text.Text text) {

    }

    private void sendTextToServer(Text visionText) {
        String recognizedText = String.valueOf(visionText);
        String userPrompt = "Your user prompt here"; // Replace with actual user prompt
        String combinedText = "Image Text: " + recognizedText + "\nUser Prompt: " + userPrompt;

        RequestBody body = RequestBody.create(
                combinedText, MediaType.parse("text/plain; charset=utf-8"));

        Request request = new Request.Builder()
                .url("https://your-server-endpoint.com/api") // Replace with your server URL
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.e(TAG, "HTTP request failed", e);
                runOnUiThread(() -> Toast.makeText(Mystral.this,
                        "Failed to send data to server", Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    runOnUiThread(() -> textView.setText(responseData));
                } else {
                    Log.e(TAG, "Server responded with error: " + response.code());
                    runOnUiThread(() -> Toast.makeText(Mystral.this,
                            "Server error: " + response.message(), Toast.LENGTH_SHORT).show());
                }
            }
        });
    }
}
