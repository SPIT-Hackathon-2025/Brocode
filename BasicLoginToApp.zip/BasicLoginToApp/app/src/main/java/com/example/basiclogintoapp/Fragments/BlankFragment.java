package com.example.basiclogintoapp.Fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.example.basiclogintoapp.R;

public class BlankFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_blank, container, false);

        // Initialize buttons and image views
        Button btnMeet1 = view.findViewById(R.id.btnMeet1);
        Button btnMeet2 = view.findViewById(R.id.btnMeet2);
        Button btnMeet3 = view.findViewById(R.id.btnMeet3);
        Button btnMeet4 = view.findViewById(R.id.btnMeet4);
        ImageView iv1 = view.findViewById(R.id.image1); // Assuming you have set an id for your ImageView in XML
        ImageView iv2 = view.findViewById(R.id.image2);
        ImageView iv3 = view.findViewById(R.id.image3);
        ImageView iv4 = view.findViewById(R.id.image4);

        // Load images using Glide
        Glide.with(this)
                .load("https://th.bing.com/th/id/OIP.7bPHbuqXnfiMIg3pumyvcgHaE5?rs=1&pid=ImgDetMain")
                .into(iv1); // Image for Doctor 1

        Glide.with(this)
                .load("https://th.bing.com/th/id/OIP._gORqJNrr2lrioBTZf8UTwHaE8?rs=1&pid=ImgDetMain")
                .into(iv2); // Image for Doctor 2

        Glide.with(this)
                .load("https://c0.wallpaperflare.com/preview/609/836/35/human-person-indoors-interior-design.jpg")
                .into(iv3); // Image for Doctor 3

        Glide.with(this)
                .load("https://p.turbosquid.com/ts-thumb/2W/5ozVZ4/bnktMR1i/10001/jpg/1439965933/1920x1080/turn_fit_q99/61bb5a9a428c29452279986ae8fbe9314d6a0501/10001-1.jpg")
                .into(iv4); // Image for Doctor 4

        // Set click listeners for each button
        View.OnClickListener meetingListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://aryan.digitalsamba.com/demo-room";
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        };

        btnMeet1.setOnClickListener(meetingListener);
        btnMeet2.setOnClickListener(meetingListener);
        btnMeet3.setOnClickListener(meetingListener);
        btnMeet4.setOnClickListener(meetingListener);

        return view;
    }
}
