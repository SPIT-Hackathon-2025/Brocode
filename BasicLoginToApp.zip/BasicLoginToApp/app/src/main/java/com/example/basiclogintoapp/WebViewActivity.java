package com.example.basiclogintoapp;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// WebViewActivity.java
public class WebViewActivity extends AppCompatActivity {
    public static final String EXTRA_URL = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        WebView webView = findViewById(R.id.webView);
        String url = getIntent().getStringExtra(EXTRA_URL);

        // Enable JavaScript (optional)
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        // Handle links within the WebView
        webView.loadUrl(url+"/embed?autostart=1");

        webView.evaluateJavascript("(function() {" +
                "var iframe = document.querySelector('iframe');" +
                "iframe.contentWindow.postMessage({" +
                "    method: 'disableControls'" +
                "}, '*');" +
                "})();", null);

//        if (url != null) {
//            webView.loadUrl(url);
//        }
    }

    @Override
    public void onBackPressed() {
        WebView webView = findViewById(R.id.webView);
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}