package com.example.basiclogintoapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Ref extends AppCompatActivity {
    private String reportName;
    private String reportText;
    private String timestamp;

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    generatePDF();
                } else {
                    Toast.makeText(this, "Storage permission is required to save PDF",
                            Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ref);

        // Get data from intent
        reportName = getIntent().getStringExtra("reportName");
        reportText = getIntent().getStringExtra("reportText");
        timestamp = getIntent().getStringExtra("timestamp");

        // Initialize views
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        TextView titleView = findViewById(R.id.reportTitle);
        TextView timestampView = findViewById(R.id.reportTimestamp);
        TextView contentView = findViewById(R.id.reportContent);
        Button downloadButton = findViewById(R.id.downloadButton);

        // Set content
        titleView.setText(reportName);
        timestampView.setText("Generated on: " + timestamp);
        contentView.setText(reportText);

        // Download button click listener
        downloadButton.setOnClickListener(v -> checkAndRequestPermissions());

        // Handle back button in toolbar
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // For Android 10 and above, we don't need external storage permission
            generatePDF();
        } else {
            // For Android 9 and below, we need to check and request permission
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                    PackageManager.PERMISSION_GRANTED) {
                generatePDF();
            } else {
                requestPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
        }
    }

    private void generatePDF() {
        try {
            File pdfFile;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // For Android 10 and above, use app-specific directory
                File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Reports");
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                pdfFile = new File(dir, createFileName());
            } else {
                // For Android 9 and below, use public directory
                File dir = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS), "Reports");
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                pdfFile = new File(dir, createFileName());
            }

            // Create PDF document
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(pdfFile));
            document.open();

            // Add title
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
            Paragraph title = new Paragraph(reportName, titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            // Add timestamp
            Font timeFont = new Font(Font.FontFamily.HELVETICA, 12, Font.ITALIC);
            Paragraph time = new Paragraph("Generated on: " + timestamp, timeFont);
            time.setAlignment(Element.ALIGN_CENTER);
            document.add(time);

            // Add empty line
            document.add(new Paragraph("\n"));

            // Add report content
            Font contentFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL);
            Paragraph content = new Paragraph(reportText, contentFont);
            content.setAlignment(Element.ALIGN_JUSTIFIED);
            document.add(content);

            document.close();

            Toast.makeText(this, "PDF saved successfully: " + pdfFile.getName(),
                    Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            Toast.makeText(this, "Error generating PDF: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private String createFileName() {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss",
                Locale.getDefault()).format(new Date());
        return reportName + "_" + timeStamp + ".pdf";
    }
}