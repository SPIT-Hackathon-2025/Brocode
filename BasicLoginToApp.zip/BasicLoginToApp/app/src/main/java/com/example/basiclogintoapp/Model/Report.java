package com.example.basiclogintoapp.Model;


public class Report {
    private String reportName;
    private String reportText;
    private String timestamp;

    // Required empty constructor for Firebase
    public Report() {}

    public Report(String reportName, String reportText, String timestamp) {
        this.reportName = reportName;
        this.reportText = reportText;
        this.timestamp = timestamp;
    }

    public String getReportName() { return reportName; }
    public void setReportName(String reportName) { this.reportName = reportName; }
    public String getReportText() { return reportText; }
    public void setReportText(String reportText) { this.reportText = reportText; }
    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
}
