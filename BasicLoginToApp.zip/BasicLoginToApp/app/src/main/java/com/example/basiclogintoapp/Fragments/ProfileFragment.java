package com.example.basiclogintoapp.Fragments;

import static android.app.Activity.RESULT_OK;
import static android.service.controls.ControlsProviderService.TAG;

import static androidx.camera.core.impl.utils.ContextUtil.getApplicationContext;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.ChangedPackages;
import android.content.pm.FeatureInfo;
import android.content.pm.InstrumentationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.content.pm.PermissionGroupInfo;
import android.content.pm.PermissionInfo;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.content.pm.SharedLibraryInfo;
import android.content.pm.VersionedPackage;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.UserHandle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.basiclogintoapp.AR_VR;
import com.example.basiclogintoapp.Activity_Shelf_2;
import com.example.basiclogintoapp.AddInventory;
import com.example.basiclogintoapp.AddMedicine;
import com.example.basiclogintoapp.AisleSelector;
import com.example.basiclogintoapp.CaseManagementSystem;
import com.example.basiclogintoapp.Courses;
import com.example.basiclogintoapp.Craft;
import com.example.basiclogintoapp.Create_Appointment;
import com.example.basiclogintoapp.FacialRecog;
import com.example.basiclogintoapp.FindJobs;
import com.example.basiclogintoapp.GetGrid;
import com.example.basiclogintoapp.GetImageInfo;
import com.example.basiclogintoapp.HomePage;
import com.example.basiclogintoapp.MainActivity;
import com.example.basiclogintoapp.MainActivity2;
import com.example.basiclogintoapp.MainActivity3;
import com.example.basiclogintoapp.MapActivity;
import com.example.basiclogintoapp.MarketPlace;
import com.example.basiclogintoapp.MessageActivity;
import com.example.basiclogintoapp.MicroStudy;
import com.example.basiclogintoapp.Model.OrderItem;
import com.example.basiclogintoapp.Model.Users;
import com.example.basiclogintoapp.NewItemPrediction;
import com.example.basiclogintoapp.OfflineClass;
import com.example.basiclogintoapp.OrderPage;
import com.example.basiclogintoapp.Payment;
import com.example.basiclogintoapp.PendingCases;
import com.example.basiclogintoapp.PendingLectures;
import com.example.basiclogintoapp.PieChart1;
import com.example.basiclogintoapp.R;
import com.example.basiclogintoapp.ReportForm;
import com.example.basiclogintoapp.ResumeScanner;
import com.example.basiclogintoapp.SendAlert;
import com.example.basiclogintoapp.Shelf3;
import com.example.basiclogintoapp.ShelfAssistant;
import com.example.basiclogintoapp.Travel;
import com.example.basiclogintoapp.UpdateItems;
import com.example.basiclogintoapp.UpdateReel;
import com.example.basiclogintoapp.Upload;
import com.example.basiclogintoapp.ViewMedicine;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import android.content.pm.PackageManager;

public class ProfileFragment extends Fragment {

    TextView username;
    ImageView imageView;
    private TextToSpeech textToSpeech;
    private TextView textView;
    DatabaseReference reference;
    TextView t1;
    FirebaseUser fuser;

    RecyclerView recyclerView;
    RelativeLayout r1,r2,r3,r4,r5;
    // Profile Image
    StorageReference storageReference;
    private static final int IMAGE_REQUEST = 1;
    private Uri imageUri;
    private StorageTask uploadTask;

    String[] data4= new String[100];
    String[] data5= new String[100];
    String[] data6= new String[100];
    int count1=0;
    String[] Image2= new String[100];
    DatabaseReference dr;
    @Override
    public void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        imageView = view.findViewById(R.id.profile_image2);
        username  = view.findViewById(R.id.username);
        r1= view.findViewById(R.id.rel1);
        r2= view.findViewById(R.id.rel2);
        r3=view.findViewById(R.id.rel3);
        r4= view.findViewById(R.id.rel4);
        r5= view.findViewById(R.id.rel5);
// Assuming t1 is a TextView
        TextView t1 = view.findViewById(R.id.points);
        textToSpeech = new TextToSpeech(getContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    textToSpeech.setLanguage(Locale.US);  // Set language to English (US)
                }
            }
        });
        fuser = FirebaseAuth.getInstance().getCurrentUser();
        dr = FirebaseDatabase.getInstance().getReference("jobOffer");
        dr.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Loop through all children in the "jobOffer" reference
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                   // Toast.makeText(getActivity(), fuser.getUid(), Toast.LENGTH_SHORT).show();

                    // Check if the key matches the current user's UID
                    if (fuser != null && Objects.equals(child.getKey(), fuser.getUid())) {
                        // Get the value associated with this key
                        String value = child.getValue(String.class);
                        // Display a Toast message with the value
                        //Toast.makeText(getActivity(),  value, Toast.LENGTH_SHORT).show();
                        showNotification(value,value);
                        // Optionally, you could break out of the loop if you only expect one match
                        break;
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle the error appropriately
               // Toast.makeText(JobOfferActivity.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


        reference = FirebaseDatabase.getInstance().getReference("MyUsers")
                .child(fuser.getUid());
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = firebaseDatabase.getReference("MyUsers").child(fuser.getUid()).child("points");

// Add a ValueEventListener to fetch the data
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Retrieve the value from the dataSnapshot
                String pointsValue = dataSnapshot.getValue(String.class);

                // Set the retrieved value to t1
                t1.setText("Age "+pointsValue);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle errors
                Log.e("Firebase", "Error fetching data", databaseError.toException());
            }
        });

        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent i = new Intent(getActivity(), MarketPlace.class);
                String text = "You have clicked marketplace page";
                textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
               startActivity(i);
            }
        });
        r2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(getActivity(), GetGrid.class);
                //Intent intent = new Intent(Intent.ACTION_MAIN);

                //intent.setComponent(new ComponentName("com.example.potoba", "com.example.potoba.MainActivity"));

                //String text = "You have clicked calender page";
                //textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
                startActivity(i);
                //openFlutterApp();

            }
        });
        r3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), GetImageInfo.class);
                String text = "You have clicked click and learn page";
                textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
                startActivity(i);
                Log.d(TAG, "onClick: " );
            }
        });
        r5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = "You have clicked Augmented Reality page";
                textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
                Intent i = new Intent(getActivity(), AR_VR.class);
                startActivity(i);
            }
        });
        r4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();

                Intent intent = new Intent(getActivity(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                getActivity().finish(); // Finish the current activity to prevent going back to it
            }
        });

        // Profile Image reference in storage
        storageReference = FirebaseStorage.getInstance().getReference("uploads");







        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                Users user = dataSnapshot.getValue(Users.class);
                username.setText(user.getUsername());

                if (user.getImageURL().equals("default")){
                    imageView.setImageResource(R.mipmap.ic_launcher);
                }else{
                    Glide.with(getContext()).load(user.getImageURL()).into(imageView);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectImage();
            }
        });





        return view;
    }

    private void SelectImage() {

        Intent i = new Intent();
        i.setType("image/*");
        i.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(i, IMAGE_REQUEST);

    }


    private String getFileExtention(Uri uri){


        ContentResolver contentResolver =getContext().getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();

        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));

    }


    private void UploadMyImage(){


        ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Uploading");
        progressDialog.show();

        if(imageUri != null) {
            final StorageReference fileReference = storageReference.child(System.currentTimeMillis()
                    + "." + getFileExtention(imageUri));


            uploadTask = fileReference.putFile(imageUri);
            uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {

                    if (!task.isSuccessful()){

                        throw  task.getException();
                    }

                    return fileReference.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {

                    if (task.isSuccessful()){

                        Uri downloadUri = task.getResult();
                        String mUri = downloadUri.toString();

                        reference = FirebaseDatabase.getInstance().getReference("MyUsers").child(fuser.getUid());


                        HashMap<String, Object> map = new HashMap<>();

                        map.put("imageURL", mUri);
                        reference.updateChildren(map);
                        progressDialog.dismiss();
                    }else{


                        Toast.makeText(getContext(), "Failed!!", Toast.LENGTH_SHORT).show();
                    }

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            });


        }else
        {
            Toast.makeText(getContext(), "No Image Selected", Toast.LENGTH_SHORT).show();
        }


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == IMAGE_REQUEST &&  resultCode == RESULT_OK
                && data != null && data.getData() != null){


            imageUri = data.getData();


            if (uploadTask != null && uploadTask.isInProgress()){
                Toast.makeText(getContext(), "Upload in progress..", Toast.LENGTH_SHORT).show();
            }else {

                UploadMyImage();
            }


        }
    }
    public void showNotification(String username, String points) {
        // Create a notification channel (required for Android Oreo and later)
        String channelId = "channel_id";
        CharSequence channelName = "Channel Name";
        int importance = NotificationManager.IMPORTANCE_DEFAULT;

        NotificationChannel channel = new NotificationChannel(channelId, channelName, importance);

        NotificationManager notificationManager = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.createNotificationChannel(channel);
        }

        // Create an intent to open a web URL when the notification is clicked
        String quizUrl = "http://54.90.176.128:8081/index.html";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(quizUrl));

        PendingIntent pendingIntent = PendingIntent.getActivity(
                getContext(),
                0,
                intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        // Create the notification
        Notification notification = new Notification.Builder(getContext(), channelId)
                .setContentTitle("Congratulations On Interview Selection")
                .setContentText(username)
                .setSmallIcon(R.drawable.logo)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true) // Notification will be removed when clicked
                .build();

        // Show the notification
        if (notificationManager != null) {
            notificationManager.notify(0, notification);
        }
    }
    private void openFlutterApp() {
        String packageName = "com.example.flutterapp"; // Replace with your Flutter app's package name
        PackageManager packageManager = new PackageManager() {
            @Override
            public PackageInfo getPackageInfo(@NonNull String s, int i) throws NameNotFoundException {
                return null;
            }

            @Override
            public PackageInfo getPackageInfo(@NonNull VersionedPackage versionedPackage, int i) throws NameNotFoundException {
                return null;
            }

            @Override
            public String[] currentToCanonicalPackageNames(@NonNull String[] strings) {
                return new String[0];
            }

            @Override
            public String[] canonicalToCurrentPackageNames(@NonNull String[] strings) {
                return new String[0];
            }

            @Nullable
            @Override
            public Intent getLaunchIntentForPackage(@NonNull String s) {
                return null;
            }

            @Nullable
            @Override
            public Intent getLeanbackLaunchIntentForPackage(@NonNull String s) {
                return null;
            }

            @Override
            public int[] getPackageGids(@NonNull String s) throws NameNotFoundException {
                return new int[0];
            }

            @Override
            public int[] getPackageGids(@NonNull String s, int i) throws NameNotFoundException {
                return new int[0];
            }

            @Override
            public int getPackageUid(@NonNull String s, int i) throws NameNotFoundException {
                return 0;
            }

            @Override
            public PermissionInfo getPermissionInfo(@NonNull String s, int i) throws NameNotFoundException {
                return null;
            }

            @NonNull
            @Override
            public List<PermissionInfo> queryPermissionsByGroup(@Nullable String s, int i) throws NameNotFoundException {
                return Collections.emptyList();
            }

            @NonNull
            @Override
            public PermissionGroupInfo getPermissionGroupInfo(@NonNull String s, int i) throws NameNotFoundException {
                return null;
            }

            @NonNull
            @Override
            public List<PermissionGroupInfo> getAllPermissionGroups(int i) {
                return Collections.emptyList();
            }

            @NonNull
            @Override
            public ApplicationInfo getApplicationInfo(@NonNull String s, int i) throws NameNotFoundException {
                return null;
            }

            @NonNull
            @Override
            public ActivityInfo getActivityInfo(@NonNull ComponentName componentName, int i) throws NameNotFoundException {
                return null;
            }

            @NonNull
            @Override
            public ActivityInfo getReceiverInfo(@NonNull ComponentName componentName, int i) throws NameNotFoundException {
                return null;
            }

            @NonNull
            @Override
            public ServiceInfo getServiceInfo(@NonNull ComponentName componentName, int i) throws NameNotFoundException {
                return null;
            }

            @NonNull
            @Override
            public ProviderInfo getProviderInfo(@NonNull ComponentName componentName, int i) throws NameNotFoundException {
                return null;
            }

            @NonNull
            @Override
            public List<PackageInfo> getInstalledPackages(int i) {
                return Collections.emptyList();
            }

            @NonNull
            @Override
            public List<PackageInfo> getPackagesHoldingPermissions(@NonNull String[] strings, int i) {
                return Collections.emptyList();
            }

            @Override
            public int checkPermission(@NonNull String s, @NonNull String s1) {
                return 0;
            }

            @Override
            public boolean isPermissionRevokedByPolicy(@NonNull String s, @NonNull String s1) {
                return false;
            }

            @Override
            public boolean addPermission(@NonNull PermissionInfo permissionInfo) {
                return false;
            }

            @Override
            public boolean addPermissionAsync(@NonNull PermissionInfo permissionInfo) {
                return false;
            }

            @Override
            public void removePermission(@NonNull String s) {

            }

            @Override
            public int checkSignatures(@NonNull String s, @NonNull String s1) {
                return 0;
            }

            @Override
            public int checkSignatures(int i, int i1) {
                return 0;
            }

            @Nullable
            @Override
            public String[] getPackagesForUid(int i) {
                return new String[0];
            }

            @Nullable
            @Override
            public String getNameForUid(int i) {
                return "";
            }

            @NonNull
            @Override
            public List<ApplicationInfo> getInstalledApplications(int i) {
                return Collections.emptyList();
            }

            @Override
            public boolean isInstantApp() {
                return false;
            }

            @Override
            public boolean isInstantApp(@NonNull String s) {
                return false;
            }

            @Override
            public int getInstantAppCookieMaxBytes() {
                return 0;
            }

            @NonNull
            @Override
            public byte[] getInstantAppCookie() {
                return new byte[0];
            }

            @Override
            public void clearInstantAppCookie() {

            }

            @Override
            public void updateInstantAppCookie(@Nullable byte[] bytes) {

            }

            @Nullable
            @Override
            public String[] getSystemSharedLibraryNames() {
                return new String[0];
            }

            @NonNull
            @Override
            public List<SharedLibraryInfo> getSharedLibraries(int i) {
                return Collections.emptyList();
            }

            @Nullable
            @Override
            public ChangedPackages getChangedPackages(int i) {
                return null;
            }

            @NonNull
            @Override
            public FeatureInfo[] getSystemAvailableFeatures() {
                return new FeatureInfo[0];
            }

            @Override
            public boolean hasSystemFeature(@NonNull String s) {
                return false;
            }

            @Override
            public boolean hasSystemFeature(@NonNull String s, int i) {
                return false;
            }

            @Nullable
            @Override
            public ResolveInfo resolveActivity(@NonNull Intent intent, int i) {
                return null;
            }

            @NonNull
            @Override
            public List<ResolveInfo> queryIntentActivities(@NonNull Intent intent, int i) {
                return Collections.emptyList();
            }

            @NonNull
            @Override
            public List<ResolveInfo> queryIntentActivityOptions(@Nullable ComponentName componentName, @Nullable Intent[] intents, @NonNull Intent intent, int i) {
                return Collections.emptyList();
            }

            @NonNull
            @Override
            public List<ResolveInfo> queryBroadcastReceivers(@NonNull Intent intent, int i) {
                return Collections.emptyList();
            }

            @Nullable
            @Override
            public ResolveInfo resolveService(@NonNull Intent intent, int i) {
                return null;
            }

            @NonNull
            @Override
            public List<ResolveInfo> queryIntentServices(@NonNull Intent intent, int i) {
                return Collections.emptyList();
            }

            @NonNull
            @Override
            public List<ResolveInfo> queryIntentContentProviders(@NonNull Intent intent, int i) {
                return Collections.emptyList();
            }

            @Nullable
            @Override
            public ProviderInfo resolveContentProvider(@NonNull String s, int i) {
                return null;
            }

            @NonNull
            @Override
            public List<ProviderInfo> queryContentProviders(@Nullable String s, int i, int i1) {
                return Collections.emptyList();
            }

            @NonNull
            @Override
            public InstrumentationInfo getInstrumentationInfo(@NonNull ComponentName componentName, int i) throws NameNotFoundException {
                return null;
            }

            @NonNull
            @Override
            public List<InstrumentationInfo> queryInstrumentation(@NonNull String s, int i) {
                return Collections.emptyList();
            }

            @Nullable
            @Override
            public Drawable getDrawable(@NonNull String s, int i, @Nullable ApplicationInfo applicationInfo) {
                return null;
            }

            @NonNull
            @Override
            public Drawable getActivityIcon(@NonNull ComponentName componentName) throws NameNotFoundException {
                return null;
            }

            @NonNull
            @Override
            public Drawable getActivityIcon(@NonNull Intent intent) throws NameNotFoundException {
                return null;
            }

            @Nullable
            @Override
            public Drawable getActivityBanner(@NonNull ComponentName componentName) throws NameNotFoundException {
                return null;
            }

            @Nullable
            @Override
            public Drawable getActivityBanner(@NonNull Intent intent) throws NameNotFoundException {
                return null;
            }

            @NonNull
            @Override
            public Drawable getDefaultActivityIcon() {
                return null;
            }

            @NonNull
            @Override
            public Drawable getApplicationIcon(@NonNull ApplicationInfo applicationInfo) {
                return null;
            }

            @NonNull
            @Override
            public Drawable getApplicationIcon(@NonNull String s) throws NameNotFoundException {
                return null;
            }

            @Nullable
            @Override
            public Drawable getApplicationBanner(@NonNull ApplicationInfo applicationInfo) {
                return null;
            }

            @Nullable
            @Override
            public Drawable getApplicationBanner(@NonNull String s) throws NameNotFoundException {
                return null;
            }

            @Nullable
            @Override
            public Drawable getActivityLogo(@NonNull ComponentName componentName) throws NameNotFoundException {
                return null;
            }

            @Nullable
            @Override
            public Drawable getActivityLogo(@NonNull Intent intent) throws NameNotFoundException {
                return null;
            }

            @Nullable
            @Override
            public Drawable getApplicationLogo(@NonNull ApplicationInfo applicationInfo) {
                return null;
            }

            @Nullable
            @Override
            public Drawable getApplicationLogo(@NonNull String s) throws NameNotFoundException {
                return null;
            }

            @NonNull
            @Override
            public Drawable getUserBadgedIcon(@NonNull Drawable drawable, @NonNull UserHandle userHandle) {
                return null;
            }

            @NonNull
            @Override
            public Drawable getUserBadgedDrawableForDensity(@NonNull Drawable drawable, @NonNull UserHandle userHandle, @Nullable Rect rect, int i) {
                return null;
            }

            @NonNull
            @Override
            public CharSequence getUserBadgedLabel(@NonNull CharSequence charSequence, @NonNull UserHandle userHandle) {
                return null;
            }

            @Nullable
            @Override
            public CharSequence getText(@NonNull String s, int i, @Nullable ApplicationInfo applicationInfo) {
                return null;
            }

            @Nullable
            @Override
            public XmlResourceParser getXml(@NonNull String s, int i, @Nullable ApplicationInfo applicationInfo) {
                return null;
            }

            @NonNull
            @Override
            public CharSequence getApplicationLabel(@NonNull ApplicationInfo applicationInfo) {
                return null;
            }

            @NonNull
            @Override
            public Resources getResourcesForActivity(@NonNull ComponentName componentName) throws NameNotFoundException {
                return null;
            }

            @NonNull
            @Override
            public Resources getResourcesForApplication(@NonNull ApplicationInfo applicationInfo) throws NameNotFoundException {
                return null;
            }

            @NonNull
            @Override
            public Resources getResourcesForApplication(@NonNull String s) throws NameNotFoundException {
                return null;
            }

            @Override
            public void verifyPendingInstall(int i, int i1) {

            }

            @Override
            public void extendVerificationTimeout(int i, int i1, long l) {

            }

            @Override
            public void setInstallerPackageName(@NonNull String s, @Nullable String s1) {

            }

            @Nullable
            @Override
            public String getInstallerPackageName(@NonNull String s) {
                return "";
            }

            @Override
            public void addPackageToPreferred(@NonNull String s) {

            }

            @Override
            public void removePackageFromPreferred(@NonNull String s) {

            }

            @NonNull
            @Override
            public List<PackageInfo> getPreferredPackages(int i) {
                return Collections.emptyList();
            }

            @Override
            public void addPreferredActivity(@NonNull IntentFilter intentFilter, int i, @Nullable ComponentName[] componentNames, @NonNull ComponentName componentName) {

            }

            @Override
            public void clearPackagePreferredActivities(@NonNull String s) {

            }

            @Override
            public int getPreferredActivities(@NonNull List<IntentFilter> list, @NonNull List<ComponentName> list1, @Nullable String s) {
                return 0;
            }

            @Override
            public void setComponentEnabledSetting(@NonNull ComponentName componentName, int i, int i1) {

            }

            @Override
            public int getComponentEnabledSetting(@NonNull ComponentName componentName) {
                return 0;
            }

            @Override
            public void setApplicationEnabledSetting(@NonNull String s, int i, int i1) {

            }

            @Override
            public int getApplicationEnabledSetting(@NonNull String s) {
                return 0;
            }

            @Override
            public boolean isSafeMode() {
                return false;
            }

            @Override
            public void setApplicationCategoryHint(@NonNull String s, int i) {

            }

            @NonNull
            @Override
            public PackageInstaller getPackageInstaller() {
                return null;
            }

            @Override
            public boolean canRequestPackageInstalls() {
                return false;
            }
        }; // FIXED: Use `this.getPackageManager()`

        Intent intent = packageManager.getLaunchIntentForPackage(packageName);
        if (intent != null) {
            startActivity(intent);
        } else {
            openPlayStore(packageName);
        }
    }

    private void openPlayStore(String packageName) {
        Intent playStoreIntent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=" + packageName));
        startActivity(playStoreIntent);
    }

}