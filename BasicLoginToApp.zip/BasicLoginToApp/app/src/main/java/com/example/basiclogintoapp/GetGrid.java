package com.example.basiclogintoapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.basiclogintoapp.Model.Report;
import com.example.basiclogintoapp.adapter.ReportAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class GetGrid extends AppCompatActivity implements ReportAdapter.OnReportClickListener {
    private RecyclerView recyclerView;
    private ReportAdapter adapter;
    private DatabaseReference databaseRef;
    private List<Report> reports;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_grid);

        recyclerView = findViewById(R.id.recyclerView);
        reports = new ArrayList<>();
        adapter = new ReportAdapter(reports, this);

        // Set up RecyclerView with Grid Layout
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(adapter);

        // Initialize Firebase
        databaseRef = FirebaseDatabase.getInstance().getReference().child("layout").child("report");
        fetchReports();
    }

    private void fetchReports() {
        databaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                reports.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Report report = snapshot.getValue(Report.class);
                    if (report != null) {
                        reports.add(report);
                    }
                }
                adapter.updateReports(reports);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(GetGrid.this, "Error: " + databaseError.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onReportClick(Report report) {
        // Handle report click - you can start a new activity to show full report
        Intent intent = new Intent(this, Ref.class);
        intent.putExtra("reportName", report.getReportName());
        intent.putExtra("reportText", report.getReportText());
        intent.putExtra("timestamp", report.getTimestamp());
        startActivity(intent);
    }
}