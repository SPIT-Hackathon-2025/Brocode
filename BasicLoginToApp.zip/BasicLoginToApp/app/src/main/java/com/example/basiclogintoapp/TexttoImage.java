package com.example.basiclogintoapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class TexttoImage extends AppCompatActivity {
    private EditText editTextPrompt;
    private Button btnGenerate;
    private ImageView imageViewResult;

    private static final String BASE_URL = "https://image.pollinations.ai/prompt/";
    private final OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_textto_image);

        editTextPrompt = findViewById(R.id.editTextPrompt);
        btnGenerate = findViewById(R.id.btnGenerate);
        imageViewResult = findViewById(R.id.imageViewResult);

        btnGenerate.setOnClickListener(v -> {
            String prompt = editTextPrompt.getText().toString().trim();
            if (!prompt.isEmpty()) {
                generateImage(prompt);
            } else {
                Toast.makeText(TexttoImage.this, "Please enter a description", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void generateImage(String prompt) {
        String url = BASE_URL + prompt.replace(" ", "%20"); // Encode spaces as %20

        Request request = new Request.Builder()
                .url(url)
                .get()
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(TexttoImage.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    runOnUiThread(() -> Toast.makeText(TexttoImage.this, "API Error", Toast.LENGTH_SHORT).show());
                    return;
                }

                String imageUrl = response.request().url().toString(); // The URL itself is the image
                runOnUiThread(() -> {
                    imageViewResult.setVisibility(View.VISIBLE);
                    Glide.with(TexttoImage.this).load(imageUrl).into(imageViewResult);
                });
            }
        });
    }
}
